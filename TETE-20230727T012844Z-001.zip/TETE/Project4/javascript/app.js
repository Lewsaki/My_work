let qrt = prompt("จำนวนสินค้า")
for(var i = 1; i <= qrt; i++){
    let item = prompt("ราคาสินค้าชิ้นที่ " + i)
    document.getElementById("price").innerHTML +="รายการสิ้นค้าชิ้นที่"+i +":"+ item +"บาท"+"<br>"
}